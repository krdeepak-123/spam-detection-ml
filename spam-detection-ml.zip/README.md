# Machine Learning Based Spam Detection System

This project detects spam messages using Machine Learning (Naive Bayes).

## How to Run
pip install -r requirements.txt
python model_training.py
python spam_detection.py

## Author
Deepak Kumar Yadav
