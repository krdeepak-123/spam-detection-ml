import pickle

model = pickle.load(open("spam_model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

def check_spam(text):
    text_vec = vectorizer.transform([text])
    result = model.predict(text_vec)
    return "Spam" if result[0] == 1 else "Not Spam"

while True:
    msg = input("Enter message (or exit): ")
    if msg.lower() == "exit":
        break
    print(check_spam(msg))
